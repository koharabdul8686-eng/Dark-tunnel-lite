package com.litetunnel.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var fTarget: EditText
    private lateinit var fProxy: EditText
    private lateinit var fPayload: EditText
    private lateinit var logBox: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var mainRoot: View
    private var mainShown = false

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val samplePayload =
        "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf][crlf]"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    private fun iconButton(res: Int, onClick: (View) -> Unit): ImageView {
        val iv = ImageView(this)
        iv.setImageResource(res)
        iv.setPadding(dp(12), dp(12), dp(12), dp(12))
        iv.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        iv.setOnClickListener { v -> onClick(v) }
        return iv
    }

    private fun divider(color: String): View {
        val v = View(this)
        v.setBackgroundColor(Color.parseColor(color))
        v.layoutParams = LinearLayout.LayoutParams(match, dp(1))
        return v
    }

    private fun field(label: String, multi: Boolean): EditText {
        val et = EditText(this)
        et.hint = label
        et.setHintTextColor(Color.parseColor("#9E9E9E"))
        et.setTextColor(Color.WHITE)
        et.textSize = 14f
        et.setBackgroundColor(Color.TRANSPARENT)
        et.setPadding(0, dp(8), 0, dp(10))
        var t = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        if (multi) t = t or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        et.inputType = t
        if (multi) {
            et.maxLines = 3
            et.gravity = Gravity.TOP
        }
        return et
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        window.statusBarColor = Color.parseColor("#1E1E1E")
        window.navigationBarColor = Color.parseColor("#121212")
        val ui = getSharedPreferences("ui", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#121212"))

        // ---- Toolbar: judul + favorit + hapus log + menu ----
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.parseColor("#2B2B2B"))
        bar.setPadding(dp(16), 0, dp(4), 0)
        val title = TextView(this)
        title.text = getString(R.string.app_name)
        title.textSize = 22f
        title.setTextColor(Color.WHITE)
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(iconButton(R.drawable.ic_heart) { showFavs() })
        bar.addView(iconButton(R.drawable.ic_delete) { clearLog() })
        bar.addView(iconButton(R.drawable.ic_more) { v -> showMenu(v) })
        root.addView(bar, LinearLayout.LayoutParams(match, dp(56)))

        root.addView(View(this), LinearLayout.LayoutParams(match, dp(40)))

        // ---- Kartu: SSH . Performance Mode . Proxy -> Target ----
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(12), dp(14), dp(4))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#2A2A2A"))
        bg.cornerRadius = dp(8).toFloat()
        card.background = bg

        val head = TextView(this)
        head.text = "SSH  \u00B7  Performance Mode  \u00B7  Proxy -> Target"
        head.textSize = 14f
        head.setTextColor(Color.WHITE)
        card.addView(head)

        fTarget = field("target", false)
        fProxy = field("proxy", false)
        fPayload = field("payload", true)
        fTarget.setText(ui.getString("target", ""))
        fProxy.setText(ui.getString("proxy", ""))
        fPayload.setText(ui.getString("payload", ""))

        card.addView(fTarget)
        card.addView(divider("#3D3D3D"))
        card.addView(fProxy)
        card.addView(divider("#3D3D3D"))
        card.addView(fPayload)

        val cardLp = LinearLayout.LayoutParams(match, ViewGroup.LayoutParams.WRAP_CONTENT)
        cardLp.setMargins(dp(12), 0, dp(12), 0)
        root.addView(card, cardLp)

        // ---- Tombol CONNECT ----
        btn = Button(this)
        btn.text = "CONNECT"
        btn.textSize = 18f
        btn.setTextColor(Color.BLACK)
        btn.letterSpacing = 0.1f
        val bbg = GradientDrawable()
        bbg.setColor(Color.parseColor("#B388FF"))
        bbg.cornerRadius = dp(4).toFloat()
        btn.background = bbg
        val btnLp = LinearLayout.LayoutParams(match, dp(52))
        btnLp.setMargins(dp(12), dp(12), dp(12), dp(8))
        root.addView(btn, btnLp)

        // ---- Log ----
        logBox = LinearLayout(this)
        logBox.orientation = LinearLayout.VERTICAL
        logBox.setPadding(dp(12), 0, dp(12), dp(12))
        logScroll = ScrollView(this)
        logScroll.addView(logBox)
        root.addView(logScroll, LinearLayout.LayoutParams(match, 0, 1f))

        btn.setOnClickListener {
            if (State.running) {
                startService(Intent(this, TunnelService::class.java).setAction(TunnelService.ACTION_STOP))
            } else if (applyConfig()) {
                val i = Intent(this, TunnelService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
        }

        mainRoot = root
        if (savedInstanceState == null) {
            setContentView(buildSplash())
            Handler(Looper.getMainLooper()).postDelayed({
                if (!isFinishing) showMain()
            }, 2500)
        } else {
            showMain()
        }
    }

    private fun showMain() {
        if (mainShown) return
        mainShown = true
        setContentView(mainRoot)
    }

    // Layar sampul: foto penuh (lebar layar), area atas/bawah memakai warna tepi foto
    private fun buildSplash(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val top = View(this)
        top.setBackgroundColor(Color.parseColor("#242322"))
        val bottom = View(this)
        bottom.setBackgroundColor(Color.parseColor("#AAA9B2"))
        val img = ImageView(this)
        img.setImageResource(R.drawable.cover)
        img.adjustViewBounds = true
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        col.addView(top, LinearLayout.LayoutParams(match, 0, 1f))
        col.addView(img, LinearLayout.LayoutParams(match, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(bottom, LinearLayout.LayoutParams(match, 0, 1f))
        col.setOnClickListener { showMain() }
        return col
    }

    // Membaca 3 kolom -> menyimpan ke konfigurasi yang dibaca TunnelService
    private fun applyConfig(): Boolean {
        val target = fTarget.text.toString().trim()
        val proxy = fProxy.text.toString().trim()
        val payload = fPayload.text.toString().trim()

        val hp = target.substringBefore('@')
        val cred = if (target.contains('@')) target.substringAfter('@') else ""
        val host = hp.substringBefore(':').trim()
        val port = if (hp.contains(':')) hp.substringAfter(':').trim() else "22"
        val user = cred.substringBefore(':')
        val pass = if (cred.contains(':')) cred.substringAfter(':') else ""
        val pHost = proxy.substringBefore(':').trim()
        val pPort = if (proxy.contains(':')) proxy.substringAfter(':').trim() else "80"

        if (host.isEmpty() || user.isEmpty()) {
            AppLog.add("Error: isi target dengan format host:port@user:pass")
            return false
        }
        if (pHost.isEmpty()) {
            AppLog.add("Error: isi proxy dengan format host:port")
            return false
        }
        if (payload.isEmpty()) {
            AppLog.add("Error: payload masih kosong (menu titik tiga > Isi payload contoh)")
            return false
        }
        if (port.toIntOrNull() == null || pPort.toIntOrNull() == null) {
            AppLog.add("Error: port harus berupa angka")
            return false
        }

        val cfg = getSharedPreferences("cfg", MODE_PRIVATE)
        cfg.edit()
            .putString("ssh_host", host)
            .putString("ssh_port", port)
            .putString("user", user)
            .putString("pass", pass)
            .putString("proxy_host", pHost)
            .putString("proxy_port", pPort)
            .putString("payload", payload)
            .apply()
        getSharedPreferences("ui", MODE_PRIVATE).edit()
            .putString("target", target)
            .putString("proxy", proxy)
            .putString("payload", payload)
            .apply()
        return true
    }

    // ---- Log ----
    private fun addLogLine(line: String) {
        val sp = SpannableString(line)
        val end = line.indexOf(']') + 1
        if (end > 0) sp.setSpan(StyleSpan(Typeface.BOLD), 0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tv = TextView(this)
        tv.text = sp
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 14f
        tv.setTextColor(Color.parseColor("#E0E0E0"))
        tv.setPadding(0, dp(4), 0, dp(4))
        logBox.addView(tv)
        logBox.addView(divider("#333333"))
        if (logBox.childCount > 800) {
            logBox.removeViewAt(0)
            logBox.removeViewAt(0)
        }
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun clearLog() {
        AppLog.clear()
        logBox.removeAllViews()
    }

    // ---- Favorit (ikon hati) ----
    private fun loadFavs(): JSONArray {
        return try {
            JSONArray(getSharedPreferences("ui", MODE_PRIVATE).getString("favs", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
    }

    private fun saveFavs(a: JSONArray) {
        getSharedPreferences("ui", MODE_PRIVATE).edit().putString("favs", a.toString()).apply()
    }

    private fun showFavs() {
        val favs = loadFavs()
        val names = ArrayList<String>()
        names.add("+ Simpan konfigurasi saat ini")
        for (i in 0 until favs.length()) {
            names.add(favs.getJSONObject(i).optString("name"))
        }
        AlertDialog.Builder(this)
            .setTitle("Favorit")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == 0) {
                    val o = JSONObject()
                    o.put("name", fTarget.text.toString().substringBefore('@').ifEmpty { "tanpa nama" })
                    o.put("target", fTarget.text.toString())
                    o.put("proxy", fProxy.text.toString())
                    o.put("payload", fPayload.text.toString())
                    favs.put(o)
                    saveFavs(favs)
                    toast("Disimpan ke favorit")
                } else {
                    val o = favs.getJSONObject(which - 1)
                    fTarget.setText(o.optString("target"))
                    fProxy.setText(o.optString("proxy"))
                    fPayload.setText(o.optString("payload"))
                    toast("Favorit dimuat")
                }
            }
            .setNeutralButton("Hapus semua") { _, _ ->
                saveFavs(JSONArray())
                toast("Favorit dihapus")
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    // ---- Menu titik tiga ----
    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Isi payload contoh")
        pm.menu.add(0, 2, 1, "Port SOCKS5 lokal")
        pm.menu.add(0, 3, 2, "Bantuan format")
        pm.menu.add(0, 4, 3, "Tentang")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> fPayload.setText(samplePayload)
                2 -> askSocksPort()
                3 -> showHelp()
                4 -> showAbout()
            }
            true
        }
        pm.show()
    }

    private fun askSocksPort() {
        val cfg = getSharedPreferences("cfg", MODE_PRIVATE)
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.setText(cfg.getString("socks_port", "1080"))
        AlertDialog.Builder(this)
            .setTitle("Port SOCKS5 lokal")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val p = et.text.toString().toIntOrNull()
                if (p != null && p in 1024..65535) {
                    cfg.edit().putString("socks_port", p.toString()).apply()
                    toast("Port SOCKS5: $p")
                } else {
                    toast("Isi port 1024 - 65535")
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle("Bantuan format")
            .setMessage(
                "target:  host:port@user:pass\n" +
                    "contoh: ssh.example.com:22@user:pass\n\n" +
                    "proxy:  host:port\n" +
                    "contoh: 1.2.3.4:80\n\n" +
                    "payload: pakai [crlf], [host], [port], [host_port], [ua]\n\n" +
                    "Setelah CONNECT berhasil, arahkan aplikasi lain ke SOCKS5 127.0.0.1 (port default 1080)."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("AANG TUNNEL LITE 1.2")
            .setMessage("SSH tunnel ringan: Payload + Proxy -> SSH, dengan SOCKS5 lokal.\nGunakan hanya dengan server yang kamu miliki atau punya izin memakainya.")
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        logBox.removeAllViews()
        val copy = synchronized(AppLog) { ArrayList(AppLog.lines) }
        copy.forEach { addLogLine(it) }
        AppLog.listener = { line -> runOnUiThread { addLogLine(line) } }
        State.onChange = { runOnUiThread { refreshButton() } }
        refreshButton()
    }

    override fun onPause() {
        AppLog.listener = null
        State.onChange = null
        super.onPause()
    }

    private fun refreshButton() {
        btn.text = if (State.running) "DISCONNECT" else "CONNECT"
    }
}
