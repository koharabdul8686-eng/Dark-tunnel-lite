package com.litetunnel.app

import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

object AppLog {
    val lines = ArrayList<String>()
    @Volatile var listener: ((String) -> Unit)? = null
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(msg: String) {
        val line = "[${fmt.format(Date())}] $msg"
        lines.add(line)
        if (lines.size > 300) lines.removeAt(0)
        listener?.invoke(line)
    }

    @Synchronized
    fun clear() = lines.clear()
}

object State {
    @Volatile var running = false
    @Volatile var onChange: (() -> Unit)? = null
    fun set(v: Boolean) {
        running = v
        onChange?.invoke()
    }
}

data class Cfg(
    val sshHost: String,
    val sshPort: Int,
    val user: String,
    val pass: String,
    val proxyHost: String,
    val proxyPort: Int,
    val socksPort: Int,
    val payload: String
)

fun buildPayload(c: Cfg): ByteArray {
    var p = c.payload
    p = p.replace("[crlf]", "\r\n")
        .replace("[cr]", "\r")
        .replace("[lf]", "\n")
        .replace("[host_port]", "${c.sshHost}:${c.sshPort}")
        .replace("[host]", c.sshHost)
        .replace("[port]", c.sshPort.toString())
        .replace("[ua]", "Mozilla/5.0 (Linux; Android 13)")
    return p.toByteArray(Charsets.ISO_8859_1)
}

/** Konek ke proxy, kirim payload, tunggu 101/200, lalu serahkan stream ke SSH. */
class PayloadProxy(
    private val proxyHost: String,
    private val proxyPort: Int,
    private val payload: ByteArray
) : com.jcraft.jsch.Proxy {
    private var sock: Socket? = null
    private var ins: InputStream? = null
    private var outs: OutputStream? = null

    override fun connect(sf: com.jcraft.jsch.SocketFactory?, host: String?, port: Int, timeout: Int) {
        AppLog.add("Connecting to proxy $proxyHost port $proxyPort")
        val s = Socket()
        s.connect(InetSocketAddress(proxyHost, proxyPort), 15000)
        s.tcpNoDelay = true
        s.soTimeout = 15000
        val i = s.getInputStream()
        val o = s.getOutputStream()

        AppLog.add("Sending Payload: " + String(payload, Charsets.ISO_8859_1).replace("\r\n", "[crlf]"))
        o.write(payload)
        o.flush()

        val head = StringBuilder()
        while (!head.endsWith("\r\n\r\n")) {
            val b = i.read()
            if (b < 0) throw IOException("Proxy closed connection")
            head.append(b.toChar())
            if (head.length > 16384) throw IOException("Header too large")
        }
        val status = head.lineSequence().first()
        AppLog.add("Response: $status")
        if (!(status.contains(" 101") || status.contains(" 200"))) {
            s.close()
            throw IOException("Bad proxy response: $status")
        }
        s.soTimeout = 0
        sock = s; ins = i; outs = o
    }

    override fun getInputStream(): InputStream? = ins
    override fun getOutputStream(): OutputStream? = outs
    override fun getSocket(): Socket? = sock
    override fun close() {
        try { sock?.close() } catch (ignored: Exception) {}
    }
}

class Tunnel(private val c: Cfg) {
    @Volatile private var running = false
    @Volatile private var session: Session? = null
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        running = true
        State.set(true)
        Thread { loop() }.start()
    }

    fun stop() {
        running = false
        AppLog.add("Closing client connection")
        try { session?.disconnect() } catch (ignored: Exception) {}
        try { server?.close() } catch (ignored: Exception) {}
    }

    private fun loop() {
        try {
            server = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress("127.0.0.1", c.socksPort))
            }
            AppLog.add("SOCKS5 listening on 127.0.0.1:${c.socksPort}")
            Thread { acceptLoop() }.start()
        } catch (e: Exception) {
            AppLog.add("Error: tidak bisa buka port ${c.socksPort}: ${e.message}")
            running = false
        }

        while (running) {
            try {
                connectOnce()
                while (running && session?.isConnected == true) Thread.sleep(1000)
            } catch (e: Exception) {
                AppLog.add("Error: ${e.message}")
            }
            try { session?.disconnect() } catch (ignored: Exception) {}
            session = null
            if (!running) break
            AppLog.add("Reconnect in 5 seconds...")
            try { Thread.sleep(5000) } catch (ignored: InterruptedException) {}
        }
        try { server?.close() } catch (ignored: Exception) {}
        AppLog.add("Disconnected")
        State.set(false)
    }

    private fun connectOnce() {
        val jsch = JSch()
        val s = jsch.getSession(c.user, c.sshHost, c.sshPort)
        s.setPassword(c.pass)
        s.setConfig("StrictHostKeyChecking", "no")
        s.setProxy(PayloadProxy(c.proxyHost, c.proxyPort, buildPayload(c)))
        s.setServerAliveInterval(20000)
        s.connect(20000)
        AppLog.add(s.serverVersion ?: "SSH connected")
        AppLog.add("Auth complete")
        AppLog.add("Connected")
        session = s
    }

    private fun acceptLoop() {
        val srv = server ?: return
        while (running) {
            try {
                val cl = srv.accept()
                pool.execute { handle(cl) }
            } catch (ignored: Exception) {
                break
            }
        }
    }

    private fun reply(o: OutputStream, code: Int) {
        o.write(byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0))
        o.flush()
    }

    private fun handle(cl: Socket) {
        var ch: ChannelDirectTCPIP? = null
        try {
            cl.soTimeout = 15000
            val i = DataInputStream(cl.getInputStream())
            val o = cl.getOutputStream()

            if (i.readUnsignedByte() != 5) return
            val n = i.readUnsignedByte()
            i.readFully(ByteArray(n))
            o.write(byteArrayOf(5, 0)); o.flush()

            i.readUnsignedByte()
            val cmd = i.readUnsignedByte()
            i.readUnsignedByte()
            val addr = when (i.readUnsignedByte()) {
                1 -> { val b = ByteArray(4); i.readFully(b); InetAddress.getByAddress(b).hostAddress }
                3 -> { val b = ByteArray(i.readUnsignedByte()); i.readFully(b); String(b) }
                4 -> { val b = ByteArray(16); i.readFully(b); InetAddress.getByAddress(b).hostAddress }
                else -> return
            }
            val port = i.readUnsignedShort()
            if (cmd != 1) { reply(o, 7); return }

            val s = session
            if (s == null || !s.isConnected) { reply(o, 1); return }

            try {
                ch = s.openChannel("direct-tcpip") as ChannelDirectTCPIP
                ch.setHost(addr)
                ch.setPort(port)
                val chIn = ch.inputStream
                val chOut = ch.outputStream
                ch.connect(15000)
                reply(o, 0)
                cl.soTimeout = 0

                val t = Thread {
                    try {
                        val buf = ByteArray(16384)
                        while (true) {
                            val r = chIn.read(buf)
                            if (r < 0) break
                            o.write(buf, 0, r); o.flush()
                        }
                    } catch (ignored: Exception) {
                    } finally {
                        try { cl.close() } catch (ignored: Exception) {}
                    }
                }
                t.start()
                val buf = ByteArray(16384)
                while (true) {
                    val r = i.read(buf)
                    if (r < 0) break
                    chOut.write(buf, 0, r); chOut.flush()
                }
            } catch (e: Exception) {
                try { reply(o, 5) } catch (ignored: Exception) {}
            }
        } catch (ignored: Exception) {
        } finally {
            try { ch?.disconnect() } catch (ignored: Exception) {}
            try { cl.close() } catch (ignored: Exception) {}
        }
    }
}
