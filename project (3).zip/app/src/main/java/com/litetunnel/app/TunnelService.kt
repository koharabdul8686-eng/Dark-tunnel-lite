package com.litetunnel.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class TunnelService : Service() {
    private var tunnel: Tunnel? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            tunnel?.stop()
            tunnel = null
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(1, buildNotification())

        if (tunnel == null) {
            val p = getSharedPreferences("cfg", MODE_PRIVATE)
            val cfg = Cfg(
                sshHost = p.getString("ssh_host", "") ?: "",
                sshPort = p.getString("ssh_port", "22")?.toIntOrNull() ?: 22,
                user = p.getString("user", "") ?: "",
                pass = p.getString("pass", "") ?: "",
                proxyHost = p.getString("proxy_host", "") ?: "",
                proxyPort = p.getString("proxy_port", "80")?.toIntOrNull() ?: 80,
                socksPort = p.getString("socks_port", "1080")?.toIntOrNull() ?: 1080,
                payload = p.getString("payload", "") ?: ""
            )
            AppLog.add("Running on ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} API ${Build.VERSION.SDK_INT}")
            tunnel = Tunnel(cfg).also { it.start() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        tunnel?.stop()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("tunnel", "Tunnel", NotificationManager.IMPORTANCE_LOW)
            )
            b = Notification.Builder(this, "tunnel")
        } else {
            b = Notification.Builder(this)
        }
        return b.setContentTitle("AANG TUNNEL LITE")
            .setContentText("Tunnel aktif - SOCKS5 127.0.0.1")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.litetunnel.app.STOP"
    }
}
