package com.litetunnel.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private val fields = LinkedHashMap<String, EditText>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.parseColor("#121212"))
        }
        scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#121212"))
            addView(root)
        }

        root.addView(TextView(this).apply {
            text = "LiteTunnel"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(10))
        })

        fun addField(key: String, label: String, def: String, type: Int = InputType.TYPE_CLASS_TEXT, lines: Int = 1) {
            val et = EditText(this).apply {
                hint = label
                setText(prefs.getString(key, def))
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                inputType = type or (if (lines > 1) InputType.TYPE_TEXT_FLAG_MULTI_LINE else 0)
                if (lines > 1) { minLines = lines; gravity = android.view.Gravity.TOP }
                textSize = 14f
            }
            fields[key] = et
            root.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        val num = InputType.TYPE_CLASS_NUMBER
        addField("ssh_host", "SSH Host", "")
        addField("ssh_port", "SSH Port", "22", num)
        addField("user", "Username", "")
        addField("pass", "Password", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        addField("proxy_host", "Proxy Host / IP", "")
        addField("proxy_port", "Proxy Port", "80", num)
        addField("socks_port", "SOCKS5 lokal port", "1080", num)
        addField(
            "payload", "Payload",
            "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf][crlf]",
            InputType.TYPE_CLASS_TEXT, 4
        )

        btn = Button(this).apply {
            text = "CONNECT"
            setBackgroundColor(Color.parseColor("#B388FF"))
            setTextColor(Color.BLACK)
        }
        root.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(12) })

        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(Color.parseColor("#DDDDDD"))
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(logView)

        btn.setOnClickListener {
            if (State.running) {
                startService(Intent(this, TunnelService::class.java).setAction(TunnelService.ACTION_STOP))
            } else {
                val e = prefs.edit()
                fields.forEach { (k, v) -> e.putString(k, v.text.toString().trim()) }
                e.apply()
                AppLog.clear()
                logView.text = ""
                val i = Intent(this, TunnelService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
        }

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        synchronized(AppLog) {
            logView.text = AppLog.lines.joinToString("\n")
        }
        AppLog.listener = { line ->
            runOnUiThread {
                logView.append(if (logView.text.isEmpty()) line else "\n$line")
                scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
            }
        }
        State.onChange = { runOnUiThread { refreshButton() } }
        refreshButton()
    }

    override fun onPause() {
        AppLog.listener = null
        State.onChange = null
        super.onPause()
    }

    private fun refreshButton() {
        btn.text = if (State.running) "DISCONNECT" else "CONNECT"
    }
}
