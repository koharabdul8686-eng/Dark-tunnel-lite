# LiteTunnel (Android)

Aplikasi SSH tunnel ringan: **Payload + Proxy -> SSH**, membuka SOCKS5 lokal (`127.0.0.1:1080`).

## Cara dapat APK lewat GitHub
1. Buat repo baru di GitHub, upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** -> workflow **Build APK** jalan otomatis (atau klik *Run workflow*).
3. Setelah hijau, buka run tersebut -> bagian **Artifacts** -> unduh `LiteTunnel-apk` -> ekstrak -> `LiteTunnel.apk`.
4. Install di HP (izinkan "Install unknown apps").

Untuk membuat Release otomatis: beri tag, misalnya `git tag v1.0 && git push origin v1.0`.
APK akan muncul di halaman **Releases**.

## Catatan
- Ini SOCKS5 lokal, bukan VPN seluruh sistem. Arahkan aplikasi lain ke `127.0.0.1:1080`
  (mis. lewat SocksDroid / Postern), atau minta tambahan fitur VPN (tun2socks).
- Placeholder payload: `[crlf] [cr] [lf] [host] [port] [host_port] [ua]`
- Gunakan hanya dengan server yang kamu miliki atau punya izin memakainya.
